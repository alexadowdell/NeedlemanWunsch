package dnasequencing;

/**
 *
 * @author alexa33
 */
public class Needleman {

    private int GAP = -4;
    private int MATCH = 2;
    private int MISMATCH = -1;

    String s1, s2;
    Cell[][] cells;
    String alignmentS1 = "";
    String alignmentS2 = "";
    

    Needleman(String s1, String s2) {
        this.s1 = " " + s1;
        this.s2 = " " + s2;
        cells = new Cell[this.s1.length()][this.s2.length()];
        makeTable();
        System.out.println("Alignment Score: " + getAlignmentScore());
        buildAlignment(this.s1.length()-1,this.s2.length()-1);

    }

//    private void testLunch() {
//        char downChar = 'A';
//        char leftChar = 'T';
//        int downValue = -8;
//        int leftValue = 2;
//        int diagValue = -4;
//
//        int currValue = compute(downChar, leftChar, downValue, leftValue, diagValue);
//        System.out.println("currValue = " + currValue);
//    }
//
//    private int compute(char downChar, char leftChar, int downValue, int leftValue, int diagValue) {
//        int fromLeft = leftValue + GAP;
//        int fromDown = downValue + GAP;
//        int fromDiag = diagValue + matchOrMismatch(leftChar, downChar);
//
//        return Math.max(fromLeft, Math.max(fromDown, fromDiag));
//    }

    private int matchOrMismatch(char ch1, char ch2) {
        if (ch1 == ch2) {
            return MATCH;
        }
        return MISMATCH;
    }

    Cell makeCell(char downChar, char leftChar, int downValue, int leftValue, int diagValue) {
        Cell returnMe;
        int fromLeft = leftValue + GAP;
        int fromDown = downValue + GAP;
        int fromDiag = diagValue + matchOrMismatch(leftChar, downChar);
        int direct = getBiggestDirection(fromLeft, fromDown, fromDiag);

        if (direct == -1) {
            returnMe = new Cell(fromDown, -1);
        } else if (direct == 0) {
            returnMe = new Cell(fromDiag, 0);
        } else {
            returnMe = new Cell(fromLeft, 1);
        }
        return returnMe;

    }

    private int getBiggestDirection(int left, int down, int diag) {

        if (left > down && left > diag) {
            return 1;
        } else if (down > left && down > diag) {
            return -1;
        } else {
            return 0;
        }
    }

    public int getAlignmentScore(){
        return cells[s1.length()-1][s2.length()-1].getValue();
    
    }
    
    private void makeTable() {
        for (int row = 0; row < s1.length(); row++) {
            cells[row][0] = new Cell(row * GAP, -1);//from the up = -1
        }
        for (int col = 0; col < s2.length(); col++) {
            cells[0][col] = new Cell(col * GAP, 1);//from the left = 1
        }
//        for (int row = 0; row < s1.length(); row++) {
//            for (int col = 0; col < s2.length(); col++) {
//                if (cells[row][col] == null) {
//                    cells[row][col] = new Cell(0, 0);
//                }
//            }
//        }
        for (int row = 1; row < s1.length(); row++) {
            for (int col = 1; col < s2.length(); col++) {
                cells[row][col] = makeCell(s2.charAt(col), s1.charAt(row), cells[row - 1][col].getValue(), cells[row][col - 1].getValue(), cells[row - 1][col - 1].getValue());
            }
        }
    }

    public String toString() {
        String returnMe = "\t";
        for (int i = 0; i < s2.length(); i++) {
            returnMe += s2.charAt(i) + "\t";
        }
        returnMe += "\n";
        for (int row = 0; row < s1.length(); row++) {
            returnMe += s1.charAt(row) + "\t";
            for (int col = 0; col < s2.length(); col++) {
                int value = cells[row][col].getValue();
                if (value >= 0) {
                    returnMe += " ";
                }
                returnMe += value + "\t";
            }
            returnMe += "\n";
        }
        return returnMe;
    }
    
    void buildAlignment(int row, int col){
        
        while (row>0 || col>0){
            int direction = cells[row][col].getDirection();
            if (direction == 1){
                alignmentS1 = "-" + alignmentS1;
                alignmentS2 = s2.charAt(col)+ alignmentS2;
                col--;
            }
            else if (direction == -1){
                alignmentS2 = "-" + alignmentS2;
                alignmentS1 = s1.charAt(row)+ alignmentS1;
                row--;
            }
            else { 
                alignmentS1 = s1.charAt(row)+ alignmentS1;
                alignmentS2 = s2.charAt(col)+ alignmentS2;
                col--;
                row--;
            }
        
        }
    
    }
    
    public String getAlignment(){
        return alignmentS1 + "\n" + alignmentS2;
    }

    public static void main(String[] args) {
        String one = "ATGG";
        String two = "ATCCCGG";
        Needleman table = new Needleman(one, two);
        System.out.println("\n" + table);
        System.out.println(table.getAlignment());
    }
}
