
package dnasequencing;


public class DNASequencing {

    public static void main(String[] args) {
        new WunchFrame();
    }
    
}
