package dnasequencing;

import java.io.File;
import java.util.ArrayList;

public class WunchFrame extends javax.swing.JFrame {

    ArrayList<String> mylist = new ArrayList<String>();

    public WunchFrame() {
        initComponents();
        setVisible(true);
        setSize(500, 700);
        setTitle("DNA Sequencing Lab");
        testFile();
        compareStrings();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        theTA = new javax.swing.JTextArea();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        theTA.setColumns(20);
        theTA.setRows(5);
        jScrollPane1.setViewportView(theTA);

        getContentPane().add(jScrollPane1, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(WunchFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(WunchFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(WunchFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(WunchFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new WunchFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea theTA;
    // End of variables declaration//GEN-END:variables

    private void testFile() {
        File aFile = new File("dna");
        System.out.println("aFile = " + aFile);

        if (aFile.isDirectory()) {
//            System.out.println("dir");
            File[] list = aFile.listFiles();
            for (File nextFile : list) {
//                emit("", "nextFile = " + nextFile.getAbsolutePath());
                MyReader mr = new MyReader(nextFile.getAbsolutePath());
                while (mr.hasMoreData()) {
                    mylist.add(mr.giveMeTheNextLine());
                }
            }
//        } else {
//            System.out.println("not a dir");
        }
        System.out.println(mylist);
    }

    void compareStrings() {
        int greaterMax = Integer.MIN_VALUE;
        String greatestAlignment = "";

        for (String nextString : mylist) {
            int max = Integer.MIN_VALUE;
            String bestAlignment = "";
            for (String stringToCompare : mylist) {
                if (!nextString.equals(stringToCompare)) {
                    Needleman grid = new Needleman(nextString, stringToCompare);
                    if (grid.getAlignmentScore() > max) {
                        max = grid.getAlignmentScore();
                        bestAlignment = grid.getAlignment();
                    }
                    // theTA.append(grid.getAlignment());
                }
            }
            theTA.append(bestAlignment + "\n");
            theTA.append("Score: " + max + "\n\n\n");
            if (max > greaterMax) {
                greaterMax = max;
                greatestAlignment = bestAlignment;
            }
        }
        theTA.append("\nBest Possible Alignment/Score \n");
        theTA.append(greatestAlignment + "\n");
        theTA.append("Best Score: " + greaterMax);
    }
}

//    private void emit(String indent, String s) {
//        theTA.append(indent + s);
//        theTA.append("\n");
//
//    }
//    private void emitDir(String indent, File dir) {
//        File[] list = dir.listFiles();
//
//        if (list != null) {
//            for (File nextF : list) {
//                emit(indent, nextF.getAbsolutePath());
//                if (nextF.isDirectory()) {
//                    emitDir(indent + "    ", nextF);
//                }
//            }
//        }
//    }

