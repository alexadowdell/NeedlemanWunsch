package dnasequencing;

/**
 *
 * @author alexa33
 */
class Cell {

    protected int value;
    protected int direction;

    public Cell() {
    }   //empty default constructor

    public Cell(int value, int direction) {   //initializing constructor
        this();   // invoke the default constructor
        this.value = value;
        this.direction = direction;
    }

    public int getValue() {
        return value;
    }

    public int getDirection() {
        return direction;
    }

    public void setValue(int value) {
        this.value = value;
    }

    public void setDirection(int direction) {
        this.direction = direction;
    }

    public String toString() {
        String returnMe = "I am a Cell: ";
        returnMe += "\tvalue=" + getValue();
        returnMe += "\tdirection=" + getDirection();
        return returnMe;
    } // toString()
}  // Cell


